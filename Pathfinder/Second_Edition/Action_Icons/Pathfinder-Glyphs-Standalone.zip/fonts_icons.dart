// Place fonts/fonts.ttf in your fonts/ directory and
// add the following to your pubspec.yaml
// flutter:
//   fonts:
//    - family: fonts
//      fonts:
//       - asset: fonts/fonts.ttf
import 'package:flutter/widgets.dart';

class Fonts {
  Fonts._();

  static const String _fontFamily = 'fonts';

  static const IconData 1action = IconData(0x2b3b, fontFamily: _fontFamily);
  static const IconData 2actions = IconData(0x2b3a, fontFamily: _fontFamily);
  static const IconData 3actions = IconData(0x2b3d, fontFamily: _fontFamily);
  static const IconData delay = IconData(0x2b53, fontFamily: _fontFamily);
  static const IconData reaction = IconData(0x2b32, fontFamily: _fontFamily);
}
